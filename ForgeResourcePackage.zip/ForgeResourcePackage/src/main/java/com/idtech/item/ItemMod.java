package com.idtech.item;

import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber
public class ItemMod {

	// Material

	// Tools

	public static void preInit(){

		// Materials

		// Tools


	}

	public static void init(){

		// Register Item Renderers

	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		// Register Items
	}
}