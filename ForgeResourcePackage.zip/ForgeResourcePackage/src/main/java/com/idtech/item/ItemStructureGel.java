package com.idtech.item;

import net.minecraft.creativetab.CreativeTabs;

public class ItemStructureGel extends QuickItem {
	
	{
		name = "Structure Gel";
		tab = CreativeTabs.MISC;
		texture = "structuregel";
	}	

}
